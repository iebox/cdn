[^1]: This is a footnote
[^label]: A footnote on "label"
[^!DEF]: The footnote for definition
