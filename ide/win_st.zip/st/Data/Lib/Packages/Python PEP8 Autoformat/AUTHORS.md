Python PEP8 Autoformat is mainly written and maintained by [Stéphane Bunel](https://bitbucket.org/StephaneBunel).

Patches, Bug Reports and Suggestions:
- Jim Wallace `https://bitbucket.org/Xatter`
- Georges Goncalves
- Anton Danilchenko `https://bitbucket.org/1st`
- oliverjanik `https://bitbucket.org/oliverjanik`
- Zhenyu Li `https://bitbucket.org/fjctlzy`
- Timon Wong `https://github.com/timonwong`
- Sergey Trupp `https://bitbucket.org/trooper`
- Christian Brassat `https://bitbucket.org/crshd`
- Christopher Welborn `https://bitbucket.org/cjwelborn`
