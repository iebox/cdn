# changelog

## 1.0.0

 - Added a test suite
 - Enforces parameter types using TypeError exceptions
 - Setting an `env` value to `None` now properly unsets the variable

## 0.9.2

 - Fix a bug that would hide the Sublime Text 2 application on OS X

## 0.9.1

 - Fix a bug launching an executable on posix platforms

## 0.9.0

 - Testing release
